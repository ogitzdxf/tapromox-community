# Tapromox Community installation

Use the repository installer instead of copying an old VPS database or environment file:

```bash
curl -fsSL https://raw.githubusercontent.com/ogitzdxf/tapromox-community/main/install.sh | sudo bash
```

The installer creates a clean runtime at `/opt/tapromox-community`, a Python virtual environment, a systemd service, and a fresh administrator credential file at `/root/tapromox-community-credentials.txt`.

No old database, API key, private license key, or production credential is part of the public Community release. The first launch creates a new SQLite database and a new administrator account from the generated environment values.

After installation:

```bash
sudo systemctl status tapromox-community --no-pager
sudo journalctl -u tapromox-community -f
```

Open `http://SERVER_IP:5000`, sign in with the credentials saved by the installer, and change the password immediately. For internet-facing use, configure HTTPS with a reverse proxy and restrict port 5000 at the firewall.
