# Tapromox Community Edition

Tapromox Community Edition is the self-hosted LXC/VPS management panel made by **ogitzdude | Pratyush**.

This repository contains the Community source bundle and a repeatable installer. It does not contain private credentials, production databases, API keys, or Pro license material.

For a manual GitHub upload, put these two files in the repository root: `install.sh` and `Tapromox-Community-Source.tar.gz`.

## One-line installation

Run this on a fresh Ubuntu or Debian VPS as a sudo-capable user:

```bash
curl -fsSL https://raw.githubusercontent.com/ogitzdxf/tapromox-community/main/install.sh | sudo bash
```

The installer:

- installs the required OS packages and Python dependencies;
- downloads the source from this GitHub repository;
- creates a dedicated virtual environment;
- generates a fresh Flask secret and a random first-run administrator password;
- creates `/etc/systemd/system/tapromox-community.service`;
- starts the panel on port `5000`.

Credentials are written to `/root/tapromox-community-credentials.txt` with mode `0600`. Change the administrator password immediately after signing in.

## Requirements

- Ubuntu 22.04/24.04 or Debian 12;
- a public VPS with at least 1 GB RAM;
- root or sudo access;
- LXC/Incus installed separately if you want to create and manage containers.

The panel listens on `0.0.0.0:5000` by default. Put it behind a reverse proxy and TLS before exposing it publicly. To change the port, edit `/etc/tapromox-community/community.env`, then run `sudo systemctl restart tapromox-community`.

## Useful commands

```bash
sudo systemctl status tapromox-community --no-pager
sudo journalctl -u tapromox-community -f
sudo systemctl restart tapromox-community
```

Community Edition does not require a Pro activation key. Pro distribution and license administration are kept separate from this public repository.
